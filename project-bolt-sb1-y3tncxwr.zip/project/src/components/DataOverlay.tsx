interface ReadoutItem {
  label: string;
  value: string;
  unit?: string;
  color?: string;
  highlight?: boolean;
}

interface EquationItem {
  latex?: string;
  text: string;
  color?: string;
}

interface DataOverlayProps {
  readouts: ReadoutItem[];
  equation?: EquationItem;
  className?: string;
}

export default function DataOverlay({ readouts, equation, className = '' }: DataOverlayProps) {
  return (
    <div className={`bg-gray-950/90 backdrop-blur-sm border border-gray-800 rounded-xl overflow-hidden ${className}`}>
      {equation && (
        <div className="px-3 py-2 border-b border-gray-800/60 bg-gray-900/50">
          <span
            className="text-xs font-mono tracking-wide"
            style={{ color: equation.color ?? '#94a3b8' }}
          >
            {equation.text}
          </span>
        </div>
      )}
      <div className="divide-y divide-gray-800/40">
        {readouts.map((r, i) => (
          <div
            key={i}
            className={`flex items-center justify-between px-3 py-1.5 gap-3 ${
              r.highlight ? 'bg-white/[0.03]' : ''
            }`}
          >
            <span className="text-[11px] text-gray-500 flex-shrink-0">{r.label}</span>
            <span
              className={`text-xs font-mono font-semibold tabular-nums text-right ${
                r.color ? '' : r.highlight ? 'text-white' : 'text-gray-300'
              }`}
              style={r.color ? { color: r.color } : undefined}
            >
              {r.value}
              {r.unit && <span className="text-gray-600 ml-0.5 text-[10px] font-normal">{r.unit}</span>}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
