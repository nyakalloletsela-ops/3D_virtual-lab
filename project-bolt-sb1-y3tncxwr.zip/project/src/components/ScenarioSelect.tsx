interface Scenario<T extends string> {
  id: T;
  label: string;
  description?: string;
  icon?: string;
}

interface ScenarioSelectProps<T extends string> {
  label?: string;
  scenarios: Scenario<T>[];
  value: T;
  onChange: (v: T) => void;
  color?: string;
}

export default function ScenarioSelect<T extends string>({
  label = 'Scenario',
  scenarios,
  value,
  onChange,
  color = 'cyan',
}: ScenarioSelectProps<T>) {
  const colorMap: Record<string, string> = {
    cyan: 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300',
    amber: 'bg-amber-500/20 border-amber-500/40 text-amber-300',
    rose: 'bg-rose-500/20 border-rose-500/40 text-rose-300',
    emerald: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300',
  };
  const activeClass = colorMap[color] ?? colorMap.cyan;

  return (
    <div>
      <p className="text-[10px] text-gray-600 font-semibold uppercase tracking-wider mb-1.5">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {scenarios.map(s => (
          <button
            key={s.id}
            onClick={() => onChange(s.id)}
            title={s.description}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
              value === s.id
                ? activeClass
                : 'border-gray-800 text-gray-500 hover:text-gray-300 hover:bg-gray-800 hover:border-gray-700'
            }`}
          >
            {s.icon && <span className="mr-1">{s.icon}</span>}
            {s.label}
          </button>
        ))}
      </div>
      {scenarios.find(s => s.id === value)?.description && (
        <p className="text-[10px] text-gray-600 mt-1">{scenarios.find(s => s.id === value)?.description}</p>
      )}
    </div>
  );
}
