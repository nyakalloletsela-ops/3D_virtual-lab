import { BookOpen, X } from 'lucide-react';
import type { Module } from '../types';

interface TheoryPanelProps {
  module: Module;
  onClose: () => void;
}

export default function TheoryPanel({ module, onClose }: TheoryPanelProps) {
  return (
    <div className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:bottom-4 md:w-80 bg-gray-900/95 backdrop-blur-sm border border-gray-700 rounded-xl p-4 z-20 shadow-2xl">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-blue-500/20 rounded-lg">
            <BookOpen size={16} className="text-blue-400" />
          </div>
          <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Theory</span>
        </div>
        <button
          onClick={onClose}
          className="text-gray-500 hover:text-gray-300 transition-colors"
        >
          <X size={16} />
        </button>
      </div>
      <h3 className="text-sm font-bold text-white mb-2">{module.name}</h3>
      <p className="text-sm text-gray-300 leading-relaxed">{module.theory}</p>
    </div>
  );
}
