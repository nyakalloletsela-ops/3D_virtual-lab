import { useState } from 'react';

interface ControlSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  color?: string;
  onChange: (v: number) => void;
  formatValue?: (v: number) => string;
  precision?: number;
}

export default function ControlSlider({
  label,
  value,
  min,
  max,
  step = 0.1,
  unit = '',
  color = '#22d3ee',
  onChange,
  formatValue,
  precision = 1,
}: ControlSliderProps) {
  const [editing, setEditing] = useState(false);
  const [inputStr, setInputStr] = useState('');

  const display = formatValue ? formatValue(value) : value.toFixed(precision);

  const commitInput = () => {
    const n = parseFloat(inputStr);
    if (!isNaN(n)) onChange(Math.min(max, Math.max(min, n)));
    setEditing(false);
  };

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-[11px] text-gray-400">{label}</span>
        {editing ? (
          <input
            autoFocus
            type="number"
            defaultValue={value}
            className="w-16 text-right text-xs font-mono bg-gray-800 border border-gray-600 rounded px-1.5 py-0.5 text-white outline-none"
            onChange={e => setInputStr(e.target.value)}
            onBlur={commitInput}
            onKeyDown={e => e.key === 'Enter' && commitInput()}
            min={min}
            max={max}
            step={step}
          />
        ) : (
          <button
            onClick={() => { setInputStr(String(value)); setEditing(true); }}
            className="text-xs font-mono tabular-nums px-1.5 py-0.5 rounded hover:bg-gray-800 transition-colors"
            style={{ color }}
            title="Click to enter exact value"
          >
            {display}{unit && <span className="text-gray-600 ml-0.5 text-[10px]">{unit}</span>}
          </button>
        )}
      </div>
      <div className="relative h-1.5 rounded-full bg-gray-800">
        <div
          className="absolute top-0 left-0 h-full rounded-full transition-none"
          style={{
            width: `${((value - min) / (max - min)) * 100}%`,
            backgroundColor: color,
            boxShadow: `0 0 6px ${color}60`,
          }}
        />
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={e => onChange(parseFloat(e.target.value))}
          className="absolute inset-0 w-full opacity-0 cursor-pointer h-full"
          style={{ margin: 0 }}
        />
      </div>
      <div className="flex justify-between text-[9px] text-gray-700">
        <span>{min}{unit}</span>
        <span>{max}{unit}</span>
      </div>
    </div>
  );
}
