import { useRef, useEffect } from 'react';

export interface DataSeries {
  label: string;
  color: string;
  points: { x: number; y: number }[];
  dashed?: boolean;
}

interface LiveChartProps {
  series: DataSeries[];
  xLabel?: string;
  yLabel?: string;
  xMin?: number;
  xMax?: number;
  yMin?: number;
  yMax?: number;
  width?: number;
  height?: number;
  markers?: { x: number; y: number; color: string; label: string }[];
  className?: string;
  title?: string;
}

export default function LiveChart({
  series,
  xLabel = 'x',
  yLabel = 'y',
  xMin: xMinProp,
  xMax: xMaxProp,
  yMin: yMinProp,
  yMax: yMaxProp,
  width = 260,
  height = 160,
  markers = [],
  className = '',
  title,
}: LiveChartProps) {
  const PAD = { top: 16, right: 12, bottom: 32, left: 38 };
  const W = width - PAD.left - PAD.right;
  const H = height - PAD.top - PAD.bottom;

  const allPts = series.flatMap(s => s.points);
  const xMin = xMinProp ?? (allPts.length ? Math.min(...allPts.map(p => p.x)) : 0);
  const xMax = xMaxProp ?? (allPts.length ? Math.max(...allPts.map(p => p.x)) : 1);
  const yMin = yMinProp ?? (allPts.length ? Math.min(...allPts.map(p => p.y)) : 0);
  const yMax = yMaxProp ?? (allPts.length ? Math.max(...allPts.map(p => p.y)) : 1);

  const xRange = xMax - xMin || 1;
  const yRange = yMax - yMin || 1;

  const toSvgX = (x: number) => PAD.left + ((x - xMin) / xRange) * W;
  const toSvgY = (y: number) => PAD.top + H - ((y - yMin) / yRange) * H;

  const makePolyline = (pts: { x: number; y: number }[]) =>
    pts.map(p => `${toSvgX(p.x).toFixed(1)},${toSvgY(p.y).toFixed(1)}`).join(' ');

  // Nice axis ticks
  const niceStep = (range: number, targetCount = 4) => {
    const rough = range / targetCount;
    const mag = Math.pow(10, Math.floor(Math.log10(rough)));
    const candidates = [1, 2, 2.5, 5, 10].map(n => n * mag);
    return candidates.find(c => range / c <= targetCount + 1) ?? rough;
  };

  const xStep = niceStep(xRange, 4);
  const yStep = niceStep(yRange, 4);

  const xTicks: number[] = [];
  for (let v = Math.ceil(xMin / xStep) * xStep; v <= xMax + xStep * 0.01; v += xStep) {
    if (v >= xMin - 0.001 && v <= xMax + 0.001) xTicks.push(parseFloat(v.toPrecision(4)));
  }
  const yTicks: number[] = [];
  for (let v = Math.ceil(yMin / yStep) * yStep; v <= yMax + yStep * 0.01; v += yStep) {
    if (v >= yMin - 0.001 && v <= yMax + 0.001) yTicks.push(parseFloat(v.toPrecision(4)));
  }

  return (
    <div className={`bg-gray-900/80 rounded-xl border border-gray-800 overflow-hidden ${className}`}>
      {title && (
        <div className="px-3 pt-2 pb-0">
          <span className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">{title}</span>
        </div>
      )}
      <svg width={width} height={height} style={{ display: 'block' }}>
        {/* Grid lines */}
        {yTicks.map(v => (
          <line
            key={v}
            x1={PAD.left} y1={toSvgY(v)}
            x2={PAD.left + W} y2={toSvgY(v)}
            stroke="#1e293b" strokeWidth={1}
          />
        ))}
        {xTicks.map(v => (
          <line
            key={v}
            x1={toSvgX(v)} y1={PAD.top}
            x2={toSvgX(v)} y2={PAD.top + H}
            stroke="#1e293b" strokeWidth={1}
          />
        ))}

        {/* Axes */}
        <line x1={PAD.left} y1={PAD.top} x2={PAD.left} y2={PAD.top + H} stroke="#334155" strokeWidth={1.5} />
        <line x1={PAD.left} y1={PAD.top + H} x2={PAD.left + W} y2={PAD.top + H} stroke="#334155" strokeWidth={1.5} />

        {/* Zero line if in range */}
        {yMin < 0 && yMax > 0 && (
          <line x1={PAD.left} y1={toSvgY(0)} x2={PAD.left + W} y2={toSvgY(0)} stroke="#334155" strokeWidth={1} strokeDasharray="3,3" />
        )}

        {/* Y ticks */}
        {yTicks.map(v => (
          <g key={v}>
            <line x1={PAD.left - 3} y1={toSvgY(v)} x2={PAD.left} y2={toSvgY(v)} stroke="#475569" strokeWidth={1} />
            <text x={PAD.left - 5} y={toSvgY(v)} textAnchor="end" dominantBaseline="middle" fill="#64748b" fontSize={9}>
              {Math.abs(v) >= 1000 ? `${(v / 1000).toFixed(1)}k` : v % 1 === 0 ? v : v.toFixed(1)}
            </text>
          </g>
        ))}

        {/* X ticks */}
        {xTicks.map(v => (
          <g key={v}>
            <line x1={toSvgX(v)} y1={PAD.top + H} x2={toSvgX(v)} y2={PAD.top + H + 3} stroke="#475569" strokeWidth={1} />
            <text x={toSvgX(v)} y={PAD.top + H + 12} textAnchor="middle" fill="#64748b" fontSize={9}>
              {v % 1 === 0 ? v : v.toFixed(1)}
            </text>
          </g>
        ))}

        {/* Axis labels */}
        <text x={PAD.left + W / 2} y={height - 3} textAnchor="middle" fill="#475569" fontSize={9}>{xLabel}</text>
        <text
          x={9}
          y={PAD.top + H / 2}
          textAnchor="middle"
          fill="#475569"
          fontSize={9}
          transform={`rotate(-90, 9, ${PAD.top + H / 2})`}
        >
          {yLabel}
        </text>

        {/* Data series */}
        {series.map((s, i) => (
          s.points.length >= 2 && (
            <polyline
              key={i}
              points={makePolyline(s.points)}
              fill="none"
              stroke={s.color}
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeDasharray={s.dashed ? '5,3' : undefined}
              style={{ filter: `drop-shadow(0 0 3px ${s.color}40)` }}
            />
          )
        ))}

        {/* Markers */}
        {markers.map((m, i) => (
          <g key={i}>
            <circle cx={toSvgX(m.x)} cy={toSvgY(m.y)} r={4} fill={m.color} style={{ filter: `drop-shadow(0 0 4px ${m.color})` }} />
            {m.label && (
              <text x={toSvgX(m.x) + 6} y={toSvgY(m.y) - 4} fill={m.color} fontSize={9} fontWeight="bold">
                {m.label}
              </text>
            )}
          </g>
        ))}
      </svg>

      {/* Legend */}
      {series.length > 1 && (
        <div className="flex flex-wrap gap-3 px-3 pb-2">
          {series.map((s, i) => (
            <div key={i} className="flex items-center gap-1.5">
              <div className="w-3 h-0.5 rounded" style={{ backgroundColor: s.color, boxShadow: `0 0 4px ${s.color}` }} />
              <span className="text-[9px] text-gray-500">{s.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
