import { useState, useMemo } from 'react';
import {
  ChevronDown, ChevronRight, FlaskConical, Atom, Leaf,
  Calculator, Menu, X, Wrench, Search, Zap, Star,
} from 'lucide-react';
import type { Category, Module } from '../types';
import { CATEGORIES, MODULES } from '../types';

const CATEGORY_ICONS: Record<Category, React.ReactNode> = {
  Mathematics: <Calculator size={15} />,
  Physics: <Atom size={15} />,
  Chemistry: <FlaskConical size={15} />,
  Biology: <Leaf size={15} />,
  Engineering: <Wrench size={15} />,
};

const CATEGORY_COLORS: Record<Category, { header: string; active: string; dot: string }> = {
  Mathematics: {
    header: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/25 hover:bg-cyan-500/15',
    active: 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300',
    dot: 'bg-cyan-400',
  },
  Physics: {
    header: 'text-amber-400 bg-amber-500/10 border-amber-500/25 hover:bg-amber-500/15',
    active: 'bg-amber-500/20 border-amber-500/40 text-amber-300',
    dot: 'bg-amber-400',
  },
  Chemistry: {
    header: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/25 hover:bg-emerald-500/15',
    active: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300',
    dot: 'bg-emerald-400',
  },
  Biology: {
    header: 'text-rose-400 bg-rose-500/10 border-rose-500/25 hover:bg-rose-500/15',
    active: 'bg-rose-500/20 border-rose-500/40 text-rose-300',
    dot: 'bg-rose-400',
  },
  Engineering: {
    header: 'text-orange-400 bg-orange-500/10 border-orange-500/25 hover:bg-orange-500/15',
    active: 'bg-orange-500/20 border-orange-500/40 text-orange-300',
    dot: 'bg-orange-400',
  },
};

const DIFFICULTY_BADGE: Record<string, string> = {
  beginner: 'text-emerald-400 bg-emerald-500/10',
  intermediate: 'text-amber-400 bg-amber-500/10',
  advanced: 'text-rose-400 bg-rose-500/10',
};

interface SidebarProps {
  selectedModule: Module | null;
  onSelectModule: (module: Module) => void;
}

function useFilteredModules(query: string) {
  return useMemo(() => {
    if (!query.trim()) return null;
    const q = query.toLowerCase();
    return MODULES.filter(
      m =>
        m.name.toLowerCase().includes(q) ||
        m.category.toLowerCase().includes(q) ||
        m.description.toLowerCase().includes(q)
    );
  }, [query]);
}

function ModuleRow({
  mod,
  isActive,
  colors,
  onClick,
}: {
  mod: Module;
  isActive: boolean;
  colors: (typeof CATEGORY_COLORS)[Category];
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-2 py-2 rounded-lg text-xs transition-all border group ${
        isActive
          ? `${colors.active} border`
          : 'text-gray-400 hover:text-gray-100 hover:bg-gray-800/70 border-transparent'
      }`}
    >
      <div className="flex items-start gap-2">
        <span className="text-gray-600 font-mono text-[10px] w-5 text-right flex-shrink-0 pt-0.5">
          {mod.id}
        </span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="leading-tight font-medium">{mod.name}</span>
            {mod.enhanced && (
              <span className="flex items-center gap-0.5 text-[9px] text-cyan-400 bg-cyan-500/10 px-1 py-0.5 rounded font-semibold flex-shrink-0">
                <Zap size={8} />
                LIVE
              </span>
            )}
          </div>
          {mod.difficulty && (
            <span className={`text-[9px] px-1.5 py-0.5 rounded-full mt-0.5 inline-block font-medium ${DIFFICULTY_BADGE[mod.difficulty]}`}>
              {mod.difficulty}
            </span>
          )}
        </div>
      </div>
    </button>
  );
}

export default function Sidebar({ selectedModule, onSelectModule }: SidebarProps) {
  const [expandedCategories, setExpandedCategories] = useState<Set<Category>>(
    new Set(['Mathematics', 'Physics'])
  );
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState('');

  const searchResults = useFilteredModules(search);

  const toggleCategory = (cat: Category) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat);
      else next.add(cat);
      return next;
    });
  };

  const handleSelect = (mod: Module) => {
    onSelectModule(mod);
    setMobileOpen(false);
    setSearch('');
  };

  const content = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-4 pt-4 pb-3 border-b border-gray-800/80">
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold text-xs">L</span>
          </div>
          <div>
            <h1 className="text-white font-bold text-sm leading-tight">Lordda 3D</h1>
            <p className="text-gray-600 text-[10px]">Discovery Lab</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-600" />
          <input
            type="text"
            placeholder="Search modules..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 rounded-lg pl-7 pr-3 py-1.5 text-xs text-gray-300 placeholder-gray-600 focus:outline-none focus:border-gray-600 transition-colors"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-400">
              <X size={11} />
            </button>
          )}
        </div>
      </div>

      {/* Module list */}
      <div className="flex-1 overflow-y-auto py-2 scrollbar-thin">
        {/* Search results */}
        {searchResults !== null ? (
          <div className="px-2">
            <p className="text-[10px] text-gray-600 px-2 pb-1">
              {searchResults.length} result{searchResults.length !== 1 ? 's' : ''}
            </p>
            {searchResults.length === 0 ? (
              <p className="text-xs text-gray-600 px-2 py-4 text-center">No modules found</p>
            ) : (
              <div className="space-y-0.5">
                {searchResults.map(mod => {
                  const colors = CATEGORY_COLORS[mod.category];
                  return (
                    <div key={mod.id}>
                      <div className="flex items-center gap-1 px-2 mb-0.5">
                        <div className={`w-1.5 h-1.5 rounded-full ${colors.dot}`} />
                        <span className="text-[9px] text-gray-600">{mod.category}</span>
                      </div>
                      <ModuleRow
                        mod={mod}
                        isActive={selectedModule?.id === mod.id}
                        colors={colors}
                        onClick={() => handleSelect(mod)}
                      />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          /* Category tree */
          CATEGORIES.map(cat => {
            const modules = MODULES.filter(m => m.category === cat);
            if (modules.length === 0) return null;
            const isExpanded = expandedCategories.has(cat);
            const colors = CATEGORY_COLORS[cat];
            const activeInCat = modules.some(m => m.id === selectedModule?.id);

            return (
              <div key={cat} className="mb-0.5 px-2">
                <button
                  onClick={() => toggleCategory(cat)}
                  className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg border transition-all text-left ${colors.header}`}
                >
                  <span className="flex-shrink-0">{CATEGORY_ICONS[cat]}</span>
                  <span className="font-semibold text-xs flex-1 tracking-wide uppercase">{cat}</span>
                  <span className="text-[10px] opacity-50 font-mono">{modules.length}</span>
                  {isExpanded ? (
                    <ChevronDown size={12} className="opacity-60" />
                  ) : (
                    <ChevronRight size={12} className="opacity-60" />
                  )}
                </button>

                {isExpanded && (
                  <div className="mt-0.5 mb-1 pl-1 space-y-0.5 border-l border-gray-800 ml-2">
                    {modules.map(mod => (
                      <ModuleRow
                        key={mod.id}
                        mod={mod}
                        isActive={selectedModule?.id === mod.id}
                        colors={colors}
                        onClick={() => handleSelect(mod)}
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* Engineering placeholder */}
        {!searchResults && (
          <div className="px-2 mt-1">
            <div className="px-2.5 py-2 rounded-lg border border-orange-500/15 bg-orange-500/5">
              <div className="flex items-center gap-2 text-orange-400/60">
                <Wrench size={13} />
                <span className="text-xs font-semibold uppercase tracking-wide">Engineering</span>
                <span className="text-[10px] opacity-50 ml-auto">Coming soon</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer stats */}
      <div className="px-4 py-2.5 border-t border-gray-800/80">
        <div className="flex items-center justify-between text-[10px] text-gray-700">
          <span>{MODULES.length} modules</span>
          <div className="flex items-center gap-1 text-cyan-600">
            <Zap size={9} />
            <span>{MODULES.filter(m => m.enhanced).length} enhanced</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <button
        onClick={() => setMobileOpen(true)}
        className="md:hidden fixed top-4 left-4 z-30 bg-gray-900 border border-gray-700 rounded-lg p-2 text-gray-300"
      >
        <Menu size={20} />
      </button>

      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="absolute inset-0 bg-black/70" onClick={() => setMobileOpen(false)} />
          <div className="relative w-72 bg-gray-950 h-full border-r border-gray-800 overflow-hidden">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-white z-10"
            >
              <X size={18} />
            </button>
            {content}
          </div>
        </div>
      )}

      <aside className="hidden md:flex w-60 flex-shrink-0 bg-gray-950 border-r border-gray-800 flex-col h-screen overflow-hidden">
        {content}
      </aside>
    </>
  );
}
