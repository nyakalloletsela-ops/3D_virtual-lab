import { Calculator, Atom, FlaskConical, Leaf, ChevronRight, Wrench, Zap } from 'lucide-react';
import type { Category } from '../types';
import { MODULES } from '../types';

interface WelcomeScreenProps {
  onSelectCategory: (cat: Category) => void;
}

const CATEGORIES_INFO = [
  {
    name: 'Mathematics' as Category,
    icon: <Calculator size={24} />,
    gradient: 'from-cyan-500/15 to-transparent',
    border: 'border-cyan-500/20 hover:border-cyan-500/40',
    text: 'text-cyan-400',
    glow: 'hover:shadow-cyan-500/10',
    count: MODULES.filter(m => m.category === 'Mathematics').length,
    topics: ['Algebra', 'Calculus', 'Geometry', 'Trigonometry'],
  },
  {
    name: 'Physics' as Category,
    icon: <Atom size={24} />,
    gradient: 'from-amber-500/15 to-transparent',
    border: 'border-amber-500/20 hover:border-amber-500/40',
    text: 'text-amber-400',
    glow: 'hover:shadow-amber-500/10',
    count: MODULES.filter(m => m.category === 'Physics').length,
    topics: ['Forces', 'Motion', 'Electricity', 'Waves'],
  },
  {
    name: 'Chemistry' as Category,
    icon: <FlaskConical size={24} />,
    gradient: 'from-emerald-500/15 to-transparent',
    border: 'border-emerald-500/20 hover:border-emerald-500/40',
    text: 'text-emerald-400',
    glow: 'hover:shadow-emerald-500/10',
    count: MODULES.filter(m => m.category === 'Chemistry').length,
    topics: ['Bonding', 'Reactions', 'Molecular Structure', 'Orbitals'],
  },
  {
    name: 'Biology' as Category,
    icon: <Leaf size={24} />,
    gradient: 'from-rose-500/15 to-transparent',
    border: 'border-rose-500/20 hover:border-rose-500/40',
    text: 'text-rose-400',
    glow: 'hover:shadow-rose-500/10',
    count: MODULES.filter(m => m.category === 'Biology').length,
    topics: ['Cells', 'Body Systems', 'DNA', 'Earth Science'],
  },
];

const ENHANCED_MODULES = MODULES.filter(m => m.enhanced);

export default function WelcomeScreen({ onSelectCategory }: WelcomeScreenProps) {
  return (
    <div className="w-full h-full flex flex-col items-center justify-start p-6 overflow-y-auto">
      <div className="max-w-3xl w-full">
        {/* Hero */}
        <div className="text-center mb-8 pt-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <span className="text-white font-bold text-lg">L</span>
            </div>
            <div className="text-left">
              <h1 className="text-2xl font-bold text-white leading-tight">Lordda 3D Discovery Lab</h1>
              <p className="text-gray-500 text-xs">Interactive concept visualization · Primary to Undergraduate</p>
            </div>
          </div>
          <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
            Explore <span className="text-white font-semibold">{MODULES.length} interactive 3D modules</span> across
            Mathematics, Physics, Chemistry, Biology, and Engineering.
          </p>

          <div className="flex items-center justify-center gap-4 mt-4 text-[11px] text-gray-700">
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 bg-gray-600 rounded-full" />Drag to orbit</span>
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 bg-gray-600 rounded-full" />Scroll to zoom</span>
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 bg-gray-600 rounded-full" />Sliders for exact values</span>
          </div>
        </div>

        {/* Enhanced modules highlight */}
        {ENHANCED_MODULES.length > 0 && (
          <div className="mb-6 bg-cyan-500/5 border border-cyan-500/15 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Zap size={14} className="text-cyan-400" />
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Enhanced Modules — Live Interactive Engine</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {ENHANCED_MODULES.map(m => (
                <button
                  key={m.id}
                  onClick={() => onSelectCategory(m.category)}
                  className="text-left p-2.5 rounded-lg bg-gray-900/60 border border-gray-800 hover:border-cyan-500/30 hover:bg-gray-900 transition-all group"
                >
                  <div className="flex items-start gap-2">
                    <span className="text-[10px] text-gray-700 font-mono mt-0.5">#{m.id}</span>
                    <div>
                      <p className="text-xs text-white font-semibold leading-tight">{m.name}</p>
                      <p className="text-[10px] text-gray-600 mt-0.5">{m.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Category cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {CATEGORIES_INFO.map(cat => (
            <button
              key={cat.name}
              onClick={() => onSelectCategory(cat.name)}
              className={`group bg-gradient-to-br ${cat.gradient} border ${cat.border} rounded-xl p-4 text-left transition-all duration-200 hover:scale-[1.01] hover:shadow-lg ${cat.glow}`}
            >
              <div className="flex items-start justify-between mb-2.5">
                <div className={`${cat.text}`}>{cat.icon}</div>
                <span className={`text-[10px] font-semibold ${cat.text} opacity-60`}>
                  {cat.count} modules
                </span>
              </div>
              <h3 className="text-white font-bold text-base mb-1">{cat.name}</h3>
              <div className="flex flex-wrap gap-x-3 gap-y-0.5 mb-3">
                {cat.topics.map(t => (
                  <span key={t} className={`text-[11px] ${cat.text} opacity-60`}>{t}</span>
                ))}
              </div>
              <div className="flex items-center gap-1 text-[11px] text-gray-600 group-hover:text-gray-400 transition-colors">
                <span>Explore</span>
                <ChevronRight size={11} />
              </div>
            </button>
          ))}

          {/* Engineering coming-soon card */}
          <button
            disabled
            className="group border border-orange-500/10 bg-orange-500/3 rounded-xl p-4 text-left opacity-60 cursor-not-allowed"
          >
            <div className="flex items-start justify-between mb-2.5">
              <Wrench size={24} className="text-orange-400" />
              <span className="text-[10px] font-semibold text-orange-400 opacity-60">Coming soon</span>
            </div>
            <h3 className="text-white font-bold text-base mb-1">Engineering</h3>
            <div className="flex flex-wrap gap-x-3 mb-3">
              {['Statics', 'Fluid Mechanics', 'Thermodynamics', 'Circuits'].map(t => (
                <span key={t} className="text-[11px] text-orange-400 opacity-40">{t}</span>
              ))}
            </div>
          </button>
        </div>

        <p className="text-[11px] text-gray-700 text-center mt-6">
          Use the sidebar search to find any topic instantly
        </p>
      </div>
    </div>
  );
}
