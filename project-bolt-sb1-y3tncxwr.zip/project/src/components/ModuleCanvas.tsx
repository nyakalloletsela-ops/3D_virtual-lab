import { lazy, Suspense } from 'react';
import type { Module } from '../types';

const MODULES_MAP: Record<number, React.LazyExoticComponent<() => JSX.Element>> = {
  1: lazy(() => import('../modules/math/AlgebraAddition')),
  2: lazy(() => import('../modules/math/AlgebraMultiplication')),
  3: lazy(() => import('../modules/math/AlgebraDivision')),
  4: lazy(() => import('../modules/math/Factorizing')),
  5: lazy(() => import('../modules/math/Expanding')),
  6: lazy(() => import('../modules/math/Slope')),
  7: lazy(() => import('../modules/math/Parabolas')),
  8: lazy(() => import('../modules/math/SystemsOfEquations')),
  9: lazy(() => import('../modules/math/UnitCircle')),
  10: lazy(() => import('../modules/math/VolumeRelationships')),
  11: lazy(() => import('../modules/math/RiemannSums')),
  12: lazy(() => import('../modules/math/TangentLine')),
  13: lazy(() => import('../modules/physics/ForcesIncline')),
  14: lazy(() => import('../modules/physics/ProjectileMotion')),
  15: lazy(() => import('../modules/physics/DisplacementDistance')),
  16: lazy(() => import('../modules/physics/CentripetalForce')),
  17: lazy(() => import('../modules/physics/Torque')),
  18: lazy(() => import('../modules/physics/Bernoulli')),
  19: lazy(() => import('../modules/physics/ElectricFields')),
  20: lazy(() => import('../modules/physics/CircuitFlow')),
  21: lazy(() => import('../modules/physics/SimpleHarmonicMotion')),
  22: lazy(() => import('../modules/chemistry/IonicBonding')),
  23: lazy(() => import('../modules/chemistry/CovalentBonding')),
  24: lazy(() => import('../modules/chemistry/BalancingEquations')),
  25: lazy(() => import('../modules/chemistry/MolecularGeometry')),
  26: lazy(() => import('../modules/chemistry/StatesOfMatter')),
  27: lazy(() => import('../modules/chemistry/AtomicOrbitals')),
  28: lazy(() => import('../modules/biology/AnimalCell')),
  29: lazy(() => import('../modules/biology/PlantCell')),
  30: lazy(() => import('../modules/biology/PlantSystems')),
  31: lazy(() => import('../modules/biology/HumanBodySystems')),
  32: lazy(() => import('../modules/biology/DNADoubleHelix')),
  33: lazy(() => import('../modules/biology/PlateTectonics')),
  // Math Batch 2
  34: lazy(() => import('../modules/math/MatrixTransformations')),
  35: lazy(() => import('../modules/math/CrossProduct')),
  // Math Batch 3
  41: lazy(() => import('../modules/math/CoordinateSystems')),
  42: lazy(() => import('../modules/math/FourierSeries')),
  43: lazy(() => import('../modules/math/Eigenvalues')),
  // Physics Batch 2
  36: lazy(() => import('../modules/physics/SpecialRelativity')),
  // Physics Batch 4
  44: lazy(() => import('../modules/physics/DopplerEffect')),
  45: lazy(() => import('../modules/physics/WaveInterference')),
  46: lazy(() => import('../modules/physics/LorentzForce')),
  47: lazy(() => import('../modules/physics/KeplersSecondLaw')),
  50: lazy(() => import('../modules/physics/FluidReynolds')),
  51: lazy(() => import('../modules/physics/ThermodynamicCycles')),
  53: lazy(() => import('../modules/physics/GyroscopicPrecession')),
  // Chemistry Batch 5
  56: lazy(() => import('../modules/chemistry/LeChatelier')),
  57: lazy(() => import('../modules/chemistry/AcidBaseTitration')),
  58: lazy(() => import('../modules/chemistry/GalvanicCell')),
  59: lazy(() => import('../modules/chemistry/HalfLife')),
  60: lazy(() => import('../modules/chemistry/EnzymeSubstrate')),
  // Biology Batch 6
  61: lazy(() => import('../modules/biology/Mitosis')),
  62: lazy(() => import('../modules/biology/SynapticNerve')),
  63: lazy(() => import('../modules/biology/CarbonCycle')),
  64: lazy(() => import('../modules/biology/NephronFiltration')),
  65: lazy(() => import('../modules/biology/ActionPotential')),
  66: lazy(() => import('../modules/biology/GlacialRetreat')),
  67: lazy(() => import('../modules/biology/AntibioticResistance')),
  68: lazy(() => import('../modules/biology/OceanicThermohaline')),
  69: lazy(() => import('../modules/biology/Photosynthesis')),
  // Engineering Batch 1
  37: lazy(() => import('../modules/engineering/StressStrain')),
  38: lazy(() => import('../modules/engineering/PIDController')),
  39: lazy(() => import('../modules/engineering/AerodynamicLift')),
  40: lazy(() => import('../modules/engineering/GearRatios')),
  // Engineering Batch 4
  48: lazy(() => import('../modules/engineering/TrussBridge')),
  49: lazy(() => import('../modules/engineering/LogicGates')),
  52: lazy(() => import('../modules/engineering/SignalModulation')),
  54: lazy(() => import('../modules/engineering/CantileverBeam')),
  55: lazy(() => import('../modules/engineering/ElectricalTransformer')),
  70: lazy(() => import('../modules/engineering/GCodeLayering')),
};

interface ModuleCanvasProps {
  module: Module;
}

function LoadingFallback() {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gray-950">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-gray-500">Loading module...</p>
      </div>
    </div>
  );
}

export default function ModuleCanvas({ module }: ModuleCanvasProps) {
  const Component = MODULES_MAP[module.id];
  if (!Component) {
    return (
      <div className="w-full h-full flex items-center justify-center">
        <p className="text-gray-500">Module #{module.id} coming soon</p>
      </div>
    );
  }
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Component />
    </Suspense>
  );
}
